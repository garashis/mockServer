package com.example.mock;

import org.mockserver.configuration.ConfigurationProperties;
import org.mockserver.integration.ClientAndServer;
import org.springframework.context.annotation.Configuration;

import static org.mockserver.integration.ClientAndServer.startClientAndServer;

@Configuration
public class TestMockServer {
    private static ClientAndServer mockServer;

    public TestMockServer() {
        mockServer = startClientAndServer(1080);
    }
}
